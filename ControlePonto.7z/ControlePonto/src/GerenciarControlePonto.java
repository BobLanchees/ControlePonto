import java.time.LocalDate;
import java.time.LocalDateTime;

public class GerenciarControlePonto {
    public static void main(String[] args) {


        Gerente gerente = new Gerente();
        gerente.setIdFunc(1);
        gerente.setNome("Geraldo");
        gerente.setEmail("Geraldinho23@gmail.com");
        gerente.setLogin("GeraldãoDeRivia");
        gerente.setSenha("Bruxo");
        gerente.setDocumento("111.111.111-11");

        Secretaria secretaria = new Secretaria();
        secretaria.setIdFunc(2);
        secretaria.setNome("Fernanda");
        secretaria.setEmail("Fernandinha62@gmail.com");
        secretaria.setTelefone("(19)99999-9992");
        secretaria.setRamal("#21");
        secretaria.setDocumento("222.222.222-22");

        Operador operador = new Operador();
        operador.setIdFunc(3);
        operador.setNome("Trafalgar");
        operador.setEmail("Trafalgar.OP@hotmail.com");
        operador.setValorHora(20.00);
        operador.setDocumento("333.333.333-33");

        RegistroPonto rg1 = new RegistroPonto();
        rg1.setFunc(gerente);
        rg1.setIdRegPonto(1);
        rg1.setDataRegistro(LocalDate.now());
        rg1.setHoraEntrada(LocalDateTime.now());
        rg1.apresentarRegistroPonto();

        RegistroPonto rg2 = new RegistroPonto();
        rg2.setFunc(secretaria);
        rg2.setIdRegPonto(2);
        rg2.setDataRegistro(LocalDate.now());
        rg2.setHoraEntrada(LocalDateTime.now());
        rg2.apresentarRegistroPonto();

        RegistroPonto rg3 = new RegistroPonto();
        rg3.setFunc(operador);
        rg3.setIdRegPonto(3);
        rg3.setDataRegistro(LocalDate.now());
        rg3.setHoraEntrada(LocalDateTime.now());
        rg3.apresentarRegistroPonto();

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        rg1.setHoraSaida(LocalDateTime.now());
        rg1.apresentarSaidaPonto();

        rg2.setHoraSaida(LocalDateTime.now());
        rg2.apresentarSaidaPonto();

        rg3.setHoraSaida(LocalDateTime.now());
        rg3.apresentarSaidaPonto();




    }
}